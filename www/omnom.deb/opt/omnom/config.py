#!/usr/bin/env python

gameMusic = 0
gameSound = 1
player_speed = 8
enemy_speed = 6
players = 1
lives = 2
mariomode = 0
paper = 0
boss = 0
greenScore = 0
purpleScore = 0
greenHits = 0
purpleHits = 0
greenPoints = 0
purplePoints = 0
greenHitsTotal = 0
purpleHitsTotal = 0
deathCount = 3
currentLvl = 0
